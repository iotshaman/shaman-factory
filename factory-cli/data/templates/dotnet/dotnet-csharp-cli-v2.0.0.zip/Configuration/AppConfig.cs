﻿namespace Shaman.CommandLineUtility.Configuration;

public class AppConfig
{

}
