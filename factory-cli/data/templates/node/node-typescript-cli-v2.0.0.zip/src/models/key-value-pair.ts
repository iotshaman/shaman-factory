export class KeyValuePair<T = string> {
  key: string;
  value: T;
}