export class Sample {
	name: string = "Sample Class";
}