const TYPES = {
  AppConfig: "AppConfig",
  Logger: "Logger",
  JsonFileService: "JsonFileService",
  //shaman: {"lifecycle": "transformation", "args": {"type": "compose", "target": "TYPES"}}
};

export { TYPES };