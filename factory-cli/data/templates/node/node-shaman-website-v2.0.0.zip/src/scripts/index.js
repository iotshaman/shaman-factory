function hello() {
  return 'Hello world!';
}