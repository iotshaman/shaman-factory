// JQuery code not real
var $ = {
  ajax: () => {}
}